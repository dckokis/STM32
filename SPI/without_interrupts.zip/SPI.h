#pragma once
#include <stm32f0xx.h>


void initSPI(void);
void sendDataSPI(int _x, int _y);
