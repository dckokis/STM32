#include "SPI.h"
#include <stm32f0xx.h>

void initSPI() {	
	RCC->AHBENR |= RCC_AHBENR_GPIOBEN | RCC_AHBENR_GPIOAEN;
	RCC->APB1ENR |= RCC_APB1ENR_SPI2EN;
	GPIOB->AFR[1] = 0 << (15 - 8) * 4;
	GPIOB->AFR[1] = 0 << (13 - 8) * 4;
	
	SPI2->CR1 = 
		  SPI_CR1_SSM 
		| SPI_CR1_SSI 
		| SPI_CR1_BR 
		| SPI_CR1_MSTR 
		| SPI_CR1_CPOL 
		| SPI_CR1_CPHA;
	
	SPI2->CR2 = SPI_CR2_DS;
	
	GPIOB->MODER |= GPIO_MODER_MODER13_1 | GPIO_MODER_MODER15_1;
	GPIOA->MODER |= GPIO_MODER_MODER8_0;
	
	GPIOB->PUPDR |= GPIO_PUPDR_PUPDR13_1 | GPIO_PUPDR_PUPDR15_1;
	GPIOA->PUPDR |= GPIO_PUPDR_PUPDR8_1;
	
	SPI2->CR1 |= SPI_CR1_SPE;
	
}

void sendDataSPI(int _x, int _y) {
	if(!(SPI2->SR & SPI_SR_BSY)) {
		GPIOA->BSRR = GPIO_BSRR_BS_8;
		SPI2->DR = (0x1U << _x) << 8 | (0x1U << _y);
		GPIOA->BRR = GPIO_BRR_BR_8;
	}
}
