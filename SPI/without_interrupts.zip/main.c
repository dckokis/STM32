#include <stm32f0xx.h>
#include <stdbool.h>
#include "buttons.h"
#include "SPI.h"

static volatile int x = 1;
static volatile int y = 1;
static volatile int ix = -1;
static volatile int iy = -1;

void Init(void);
void Init() {
	RCC->AHBENR |= RCC_AHBENR_GPIOCEN|RCC_AHBENR_GPIOAEN;
	GPIOA->MODER &= ~GPIO_MODER_MODER0;
	
	GPIOC->MODER |= GPIO_MODER_MODER6_0 | GPIO_MODER_MODER7_0 | GPIO_MODER_MODER8_0 | GPIO_MODER_MODER9_0;
	
	GPIOC->MODER &= ~GPIO_MODER_MODER12;
	GPIOC->MODER |=	GPIO_MODER_MODER12_0;
	GPIOA->MODER &= ~GPIO_MODER_MODER4;
	GPIOA->PUPDR |= GPIO_PUPDR_PUPDR4_1;
	GPIOA->PUPDR |= GPIO_PUPDR_PUPDR5_1;
	GPIOA->MODER &= ~GPIO_MODER_MODER5;
	GPIOA->MODER &= ~GPIO_MODER_MODER15;
	GPIOA->MODER |= GPIO_MODER_MODER15_0;
}

void Sys_Tick(void);
void Sys_Tick(void) {
	SysTick->CTRL = SysTick_CTRL_ENABLE_Msk | SysTick_CTRL_CLKSOURCE_Msk | SysTick_CTRL_TICKINT_Msk;
	SystemCoreClockUpdate();
	SysTick->LOAD = SystemCoreClock / 1000 - 1;//10ms
}


void SysTick_Handler(void);
void SysTick_Handler(void) {	
	ask_buttons_1_3();
	ask_buttons_2_4();
	if(ix <= 1) {
		sendDataSPI(x+ix, y);
		ix++;
		return;
	} else {
		ix = -1;
	}
	if(iy <= 1) {
		sendDataSPI(x, y+iy);
		iy++;
		return;
	} else {
		iy = -1;
	}
}

int main(void) { 
	Init();
	Sys_Tick();
	initSPI();
	while(1){
		if (keys[3].state) {
			if(x > 1) {
				--x;
			}
			keys[3].state = false;
		}

		if (keys[1].state) {
			if(x < 6) {
				++x;
			}
			keys[1].state = false;
		}

		if (keys[0].state) {
			if(y > 1) {
				--y;
			}
			keys[0].state = false;
	  }
		if (keys[2].state) {
			if(y < 6){
				++y;
			}
			keys[2].state = false;
		}
	}
}
